import { describe, it, expect } from "vitest";
import { HealthCheckResponse, ListSubjectsResponseItem } from "../lib/api-zod/src";

describe("API Schema & Zod Validations", () => {
  it("should validate health check response correctly", () => {
    const valid = { status: "ok" };
    expect(HealthCheckResponse.safeParse(valid).success).toBe(true);

    const invalid = { status: 123 };
    expect(HealthCheckResponse.safeParse(invalid).success).toBe(false);
  });

  it("should validate subject response item schema", () => {
    const validSubject = {
      id: 1,
      name: "Physics",
      nameBn: "পদার্থবিজ্ঞান",
      icon: "Atom",
      color: "#06B6D4",
      description: "পদার্থবিজ্ঞান সংক্রান্ত প্রশ্ন ও অধ্যায়সমূহ।",
      chapterCount: 5,
      questionCount: 40,
      category: "Science",
    };

    const parsed = ListSubjectsResponseItem.safeParse(validSubject);
    expect(parsed.success).toBe(true);
    if (parsed.success) {
      expect(parsed.data.nameBn).toBe("পদার্থবিজ্ঞান");
    }
  });

  it("should fail validation if required fields are missing", () => {
    const missingNameBn = {
      id: 1,
      name: "Physics",
      // nameBn is missing
      icon: "Atom",
      color: "#06B6D4",
      description: "Sample",
      chapterCount: 2,
      questionCount: 10,
    };

    const parsed = ListSubjectsResponseItem.safeParse(missingNameBn);
    expect(parsed.success).toBe(false);
  });
});
