import { describe, it, expect } from "vitest";

// Pure calculation logic function extracted from streak rules for deterministic unit testing
function calculateNewStreak(
  currentStreak: number,
  longestStreak: number,
  lastActiveDate: string,
  today: string,
  yesterday: string,
): { newStreak: number; newLongest: number; shouldUpdate: boolean } {
  if (lastActiveDate === today) {
    return { newStreak: currentStreak, newLongest: longestStreak, shouldUpdate: false };
  }

  let newStreak = 1;
  if (lastActiveDate === yesterday) {
    newStreak = currentStreak + 1;
  }

  const newLongest = Math.max(longestStreak, newStreak);
  return { newStreak, newLongest, shouldUpdate: true };
}

describe("Student Streak & Daily Activity Calculations", () => {
  const today = "2026-10-23";
  const yesterday = "2026-10-22";
  const threeDaysAgo = "2026-10-20";

  it("should not increment streak if user was already active today", () => {
    const result = calculateNewStreak(5, 10, today, today, yesterday);
    expect(result.shouldUpdate).toBe(false);
    expect(result.newStreak).toBe(5);
    expect(result.newLongest).toBe(10);
  });

  it("should increment streak if user was active yesterday", () => {
    const result = calculateNewStreak(5, 10, yesterday, today, yesterday);
    expect(result.shouldUpdate).toBe(true);
    expect(result.newStreak).toBe(6);
    expect(result.newLongest).toBe(10);
  });

  it("should update longestStreak if newStreak exceeds previous record", () => {
    const result = calculateNewStreak(10, 10, yesterday, today, yesterday);
    expect(result.shouldUpdate).toBe(true);
    expect(result.newStreak).toBe(11);
    expect(result.newLongest).toBe(11);
  });

  it("should reset streak to 1 if user missed a day", () => {
    const result = calculateNewStreak(15, 20, threeDaysAgo, today, yesterday);
    expect(result.shouldUpdate).toBe(true);
    expect(result.newStreak).toBe(1);
    expect(result.newLongest).toBe(20); // Longest record preserved
  });
});
