import { describe, it, expect } from "vitest";
import { parseQuestionCode } from "../artifacts/api-server/src/lib/parseQuestionCode";

describe("Question Import Code Parser", () => {
  it("should successfully parse standard Bengali MCQ with English letters", () => {
    const rawCode = `
@subject: পদার্থবিজ্ঞান
@chapter: গতি
@source: ঢাকা বোর্ড
@year: 2024
@difficulty: medium

Q: বেগের পরিবর্তনের হারকে কী বলে?
A) দ্রুতি
B) ত্বরণ
C) মন্দন
D) সরণ
Answer: B
Explain: সময়ের সাথে বেগের পরিবর্তনের হারকে ত্বরণ বলা হয়। এর একক m/s^2।
`;

    const { questions, errors } = parseQuestionCode(rawCode);

    expect(errors).toHaveLength(0);
    expect(questions).toHaveLength(1);

    const q = questions[0];
    expect(q.subjectName).toBe("পদার্থবিজ্ঞান");
    expect(q.chapterName).toBe("গতি");
    expect(q.source).toBe("ঢাকা বোর্ড");
    expect(q.year).toBe(2024);
    expect(q.difficulty).toBe("medium");
    expect(q.questionText).toBe("বেগের পরিবর্তনের হারকে কী বলে?");
    expect(q.options).toEqual(["দ্রুতি", "ত্বরণ", "মন্দন", "সরণ"]);
    expect(q.correctIndex).toBe(1); // 'B' is index 1
    expect(q.explanation).toContain("সময়ের সাথে বেগের পরিবর্তনের হারকে ত্বরণ বলা হয়");
  });

  it("should successfully parse Bengali numerals/letters (ক, খ, গ, ঘ)", () => {
    const rawCode = `
@subject: জীববিজ্ঞান
@chapter: কোষ ও এর গঠন

Q: উদ্ভিদকোষের প্রধান বৈশিষ্ট্য কোনটি?
ক) প্লাস্টিড উপস্থিতি
খ) সেন্ট্রোসোম উপস্থিতি
গ) লাইসোসোম প্রাচুর্য
ঘ) কোষপ্রাচীরের অনুপস্থিতি
Answer: ক
Explain: উদ্ভিদকোষে অনন্য প্লাস্টিড ও সেলুলোজ নির্মিত কোষপ্রাচীর থাকে।
`;

    const { questions, errors } = parseQuestionCode(rawCode);

    expect(errors).toHaveLength(0);
    expect(questions).toHaveLength(1);
    expect(questions[0].correctIndex).toBe(0); // 'ক' is index 0
    expect(questions[0].options[0]).toBe("প্লাস্টিড উপস্থিতি");
  });

  it("should return an error when @subject or @chapter is missing", () => {
    const rawCode = `
Q: ত্বরণের একক কী?
A) m/s
B) m/s^2
Answer: B
`;

    const { questions, errors } = parseQuestionCode(rawCode);
    expect(questions).toHaveLength(0);
    expect(errors.length).toBeGreaterThan(0);
    expect(errors[0].message).toContain("@subject");
  });

  it("should return an error when fewer than 2 options are provided", () => {
    const rawCode = `
@subject: গণিত
@chapter: সেট

Q: শূন্য সেট কি?
A) যার উপাদান নেই
Answer: A
`;

    const { questions, errors } = parseQuestionCode(rawCode);
    expect(questions).toHaveLength(0);
    expect(errors.length).toBeGreaterThan(0);
    expect(errors[0].message).toContain("কমপক্ষে ২টি অপশন দরকার");
  });

  it("should handle multiple questions separated by '---'", () => {
    const rawCode = `
@subject: রসায়ন
@chapter: মৌলের পর্যায়বৃত্ত ধর্ম

Q: পর্যায় সারণির ১ম গ্রুপে কয়টি মৌল আছে?
A) ২
B) ৭
C) ৮
D) ১৮
Answer: B
Explain: ১ম গ্রুপে হাইড্রোজেন সহ মোট ৭টি মৌল রয়েছে।
---
Q: হ্যালোজেন মৌলসমূহ কত নং গ্রুপে অবস্থিত?
A) ১৫
B) ১৬
C) ১৭
D) ১৮
Answer: C
Explain: ১৭ নং গ্রুপের মৌলগুলোকে হ্যালোজেন বলা হয়।
`;

    const { questions, errors } = parseQuestionCode(rawCode);
    expect(errors).toHaveLength(0);
    expect(questions).toHaveLength(2);
    expect(questions[0].correctIndex).toBe(1); // B
    expect(questions[1].correctIndex).toBe(2); // C
    // Check that subject and chapter persisted across blocks
    expect(questions[1].subjectName).toBe("রসায়ন");
    expect(questions[1].chapterName).toBe("মৌলের পর্যায়বৃত্ত ধর্ম");
  });
});
