import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  test: {
    globals: true,
    environment: "node",
    include: ["tests/**/*.test.ts", "artifacts/**/*.test.ts"],
    coverage: {
      provider: "v8",
      reporter: ["text", "json", "html"],
    },
  },
  resolve: {
    alias: {
      "@workspace/api-zod": path.resolve(__dirname, "./lib/api-zod/src"),
      "@workspace/db": path.resolve(__dirname, "./lib/db/src"),
    },
  },
});
